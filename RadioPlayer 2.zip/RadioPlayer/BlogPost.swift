//
//  BlogPost.swift
//  LifeApp
//
//  Created by Marcy Thompson on 5/23/16.
//  Copyright © 2016 Marcella Thompson. All rights reserved.
//

import Foundation

class BlogPost {
    
    var postTitle: String = String()
    var postLink: String = String()
}