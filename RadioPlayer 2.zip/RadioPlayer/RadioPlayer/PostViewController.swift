//
//  PostViewController.swift
//  WCNP
//
//  Created by Marcy Thompson on 3/21/17.
//  Copyright © 2017 Marcella Thompson. All rights reserved.
//

import UIKit

class PostViewController: UIViewController, UIWebViewDelegate {


    @IBOutlet weak var web: UIWebView!
    @IBOutlet weak var activity: UIActivityIndicatorView!
    
    var postLink: String = String()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        let url: URL = URL(string: postLink)!
        let request: URLRequest = URLRequest(url: url)
        web.loadRequest(request)
        web.delegate = self
    }
    
    func webViewDidStartLoad(_ webView: UIWebView)  {
        activity.isHidden = false
        activity.startAnimating()
    }
    
    func webViewDidFinishLoad(_ webView: UIWebView)  {
        activity.isHidden = true
        activity.stopAnimating()
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}
