//
//  RadioPlayer.swift
//  RadioPlayer
//
//  Created by Marcy Thompson on 6/5/16.
//  Copyright © 2016 Marcella Thompson. All rights reserved.
//

import Foundation
import AVFoundation

class RadioPlayer {
    static let sharedInstance = RadioPlayer()
    
    fileprivate var player = AVPlayer(url: URL(string: "https://us8.listen2myradio.com:2199/tunein/ghloisvo.pls")!)
    fileprivate var isPlaying = false
    
    func play() {
        player.play()
        isPlaying = true
    }
    
    func pause() {
        player.pause()
        isPlaying = false
    }
    
    func toggle() {
        if isPlaying == true {
            pause()
        } else {
            play()
        }
    }

    func currentlyPlaying() -> Bool {
        return isPlaying
    }
}
  
