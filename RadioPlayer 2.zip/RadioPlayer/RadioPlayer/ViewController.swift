//
//  ViewController.swift
//  RadioPlayer
//
//  Created by Marcy Thompson on 2/20/16.
//  Copyright © 2016 Marcella Thompson. All rights reserved.
//

import UIKit
import AVFoundation
import MediaPlayer

class ViewController: UIViewController {

    @IBOutlet weak var playButton: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        do {
            try AVAudioSession.sharedInstance().setCategory(AVAudioSessionCategoryPlayback)
            UIApplication.shared.beginReceivingRemoteControlEvents()
            print("Receiving remote control events\n")
        } catch {
            print("Audio Session error.\n")
            
        }
        // Do any additional setup after loading the view, typically from a nib.
        
        if NSClassFromString("MPNowPlayingInfoCenter") != nil {
            let image:UIImage = UIImage(named: "Pic")! // comment this if you don't use an image
            let albumArt = MPMediaItemArtwork(image: image) // comment this if you don't use an image
            let songInfo = [
                MPMediaItemPropertyTitle: "WCNP 89.5",
                MPMediaItemPropertyArtwork: albumArt // comment this if you don't use an image
            ] as [String : Any]
            MPNowPlayingInfoCenter.default().nowPlayingInfo = songInfo
        }
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


    @IBAction func playButtonPressed(_ sender: UIButton) {
        toggle()
    }
    
    func toggle() {
        if RadioPlayer.sharedInstance.currentlyPlaying() {
            pauseRadio()
        } else {
            playRadio()
        }
    }
    
    func playRadio() {
        RadioPlayer.sharedInstance.play()
        
    }
    
    func pauseRadio() {
        RadioPlayer.sharedInstance.pause()
       
        
    }
}

